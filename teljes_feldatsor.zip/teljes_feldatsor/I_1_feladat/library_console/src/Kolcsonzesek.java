public class Kolcsonzesek {
    int kolcsonzoId;
    String iro;
    String mufaj;
    String cim;
}
