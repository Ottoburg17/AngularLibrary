public class Kolcsonzok {
    String nev;
    String szulIdo;
}
