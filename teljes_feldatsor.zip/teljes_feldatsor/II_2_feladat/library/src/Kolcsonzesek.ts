export interface Kolcsonzesek {
    id: number;
    kolcsonzokId: number;
    iro: string;
    mufaj: string;
    cim: string;
}