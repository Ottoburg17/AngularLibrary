export interface Kolcsonzesek {
    id: any;
    kolcsonzoId: any;
    iro: string;
    mufaj: string;
    cim: string;
}